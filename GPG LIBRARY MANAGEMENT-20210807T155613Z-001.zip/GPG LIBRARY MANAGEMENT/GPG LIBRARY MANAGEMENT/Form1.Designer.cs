﻿namespace GPG_LIBRARY_MANAGEMENT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel4 = new System.Windows.Forms.Panel();
            this.homepanel = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.forgetpanel = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnforgetgo = new System.Windows.Forms.Button();
            this.txtforgetconpass = new System.Windows.Forms.TextBox();
            this.txtforgetpass = new System.Windows.Forms.TextBox();
            this.txtforgetpetname = new System.Windows.Forms.TextBox();
            this.txtfogetid = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.panelchangepasswoed = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnchange = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.txtchangeconpassword = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtchangenewpass = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtchangeoldpass = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Changeadmin = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pnlnewadmin = new System.Windows.Forms.Panel();
            this.txtadhar = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtdob = new System.Windows.Forms.TextBox();
            this.newadminpanel = new System.Windows.Forms.Label();
            this.txtpetname = new System.Windows.Forms.TextBox();
            this.btnreset = new System.Windows.Forms.Button();
            this.txtpassnew = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtconpass = new System.Windows.Forms.TextBox();
            this.txtidnew = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.oldadminpanel = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.txtoldpass = new System.Windows.Forms.TextBox();
            this.txtoldid = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.loginpanal = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnlogin = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnmenulogin = new System.Windows.Forms.Button();
            this.btnnewAdmin = new System.Windows.Forms.Button();
            this.btnchangpass = new System.Windows.Forms.Button();
            this.btnforget = new System.Windows.Forms.Button();
            this.pnlHedding = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.txtadmin = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel4.SuspendLayout();
            this.homepanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.forgetpanel.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelchangepasswoed.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.Changeadmin.SuspendLayout();
            this.pnlnewadmin.SuspendLayout();
            this.oldadminpanel.SuspendLayout();
            this.loginpanal.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlHedding.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel4.Controls.Add(this.homepanel);
            this.panel4.Controls.Add(this.forgetpanel);
            this.panel4.Controls.Add(this.panelchangepasswoed);
            this.panel4.Controls.Add(this.dateTimePicker1);
            this.panel4.Controls.Add(this.Changeadmin);
            this.panel4.Controls.Add(this.loginpanal);
            this.panel4.Controls.Add(this.btnmenulogin);
            this.panel4.Controls.Add(this.btnnewAdmin);
            this.panel4.Controls.Add(this.btnchangpass);
            this.panel4.Controls.Add(this.btnforget);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(20, 108);
            this.panel4.MaximumSize = new System.Drawing.Size(1325, 567);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1325, 567);
            this.panel4.TabIndex = 56;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // homepanel
            // 
            this.homepanel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.homepanel.Controls.Add(this.panel2);
            this.homepanel.Controls.Add(this.button7);
            this.homepanel.Location = new System.Drawing.Point(0, 0);
            this.homepanel.MaximumSize = new System.Drawing.Size(1325, 567);
            this.homepanel.Name = "homepanel";
            this.homepanel.Size = new System.Drawing.Size(1325, 567);
            this.homepanel.TabIndex = 60;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18.Location = new System.Drawing.Point(392, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(350, 27);
            this.label18.TabIndex = 17;
            this.label18.Text = "LIBRARY MANAGEMENT";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Location = new System.Drawing.Point(30, 30);
            this.panel2.MaximumSize = new System.Drawing.Size(1267, 509);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1267, 509);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint_1);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.button2);
            this.panel6.Controls.Add(this.txtadmin);
            this.panel6.Controls.Add(this.button4);
            this.panel6.Controls.Add(this.button5);
            this.panel6.Controls.Add(this.button9);
            this.panel6.Controls.Add(this.button6);
            this.panel6.Controls.Add(this.button8);
            this.panel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel6.Location = new System.Drawing.Point(814, 21);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(428, 463);
            this.panel6.TabIndex = 16;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.Location = new System.Drawing.Point(228, 156);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(171, 81);
            this.button2.TabIndex = 13;
            this.button2.Text = "Student Reocrd ";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button4.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button4.Location = new System.Drawing.Point(228, 269);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(171, 72);
            this.button4.TabIndex = 12;
            this.button4.Text = "Book Essu ";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button5.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button5.Location = new System.Drawing.Point(228, 354);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(171, 81);
            this.button5.TabIndex = 13;
            this.button5.Text = "ABOUT";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button9.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button9.Location = new System.Drawing.Point(22, 159);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(172, 82);
            this.button9.TabIndex = 14;
            this.button9.Text = "Book Entry panel";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button6.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button6.Location = new System.Drawing.Point(22, 353);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(172, 82);
            this.button6.TabIndex = 14;
            this.button6.Text = "HELP";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button8.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button8.Location = new System.Drawing.Point(19, 265);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(175, 77);
            this.button8.TabIndex = 11;
            this.button8.Text = "Book Return";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox4.Image = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.WhatsApp_Image_2017_11_02_at_02_52_28;
            this.pictureBox4.Location = new System.Drawing.Point(21, 22);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(771, 462);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // forgetpanel
            // 
            this.forgetpanel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.forgetpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.forgetpanel.Controls.Add(this.panel5);
            this.forgetpanel.Controls.Add(this.pictureBox3);
            this.forgetpanel.Controls.Add(this.label22);
            this.forgetpanel.ForeColor = System.Drawing.Color.DarkSeaGreen;
            this.forgetpanel.Location = new System.Drawing.Point(40, 65);
            this.forgetpanel.MaximumSize = new System.Drawing.Size(1235, 460);
            this.forgetpanel.Name = "forgetpanel";
            this.forgetpanel.Size = new System.Drawing.Size(1235, 460);
            this.forgetpanel.TabIndex = 9;
            this.forgetpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel5.Controls.Add(this.btnforgetgo);
            this.panel5.Controls.Add(this.txtforgetconpass);
            this.panel5.Controls.Add(this.txtforgetpass);
            this.panel5.Controls.Add(this.txtforgetpetname);
            this.panel5.Controls.Add(this.txtfogetid);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label25);
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(493, 60);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(588, 320);
            this.panel5.TabIndex = 6;
            // 
            // btnforgetgo
            // 
            this.btnforgetgo.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.btnforgetgo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnforgetgo.ForeColor = System.Drawing.Color.White;
            this.btnforgetgo.Location = new System.Drawing.Point(471, 278);
            this.btnforgetgo.Name = "btnforgetgo";
            this.btnforgetgo.Size = new System.Drawing.Size(114, 39);
            this.btnforgetgo.TabIndex = 10;
            this.btnforgetgo.Text = "Go";
            this.btnforgetgo.UseVisualStyleBackColor = true;
            this.btnforgetgo.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtforgetconpass
            // 
            this.txtforgetconpass.Location = new System.Drawing.Point(197, 202);
            this.txtforgetconpass.Name = "txtforgetconpass";
            this.txtforgetconpass.PasswordChar = '*';
            this.txtforgetconpass.Size = new System.Drawing.Size(212, 26);
            this.txtforgetconpass.TabIndex = 9;
            // 
            // txtforgetpass
            // 
            this.txtforgetpass.Location = new System.Drawing.Point(196, 139);
            this.txtforgetpass.Name = "txtforgetpass";
            this.txtforgetpass.PasswordChar = '*';
            this.txtforgetpass.Size = new System.Drawing.Size(212, 26);
            this.txtforgetpass.TabIndex = 8;
            // 
            // txtforgetpetname
            // 
            this.txtforgetpetname.Location = new System.Drawing.Point(196, 74);
            this.txtforgetpetname.Name = "txtforgetpetname";
            this.txtforgetpetname.Size = new System.Drawing.Size(212, 26);
            this.txtforgetpetname.TabIndex = 7;
            // 
            // txtfogetid
            // 
            this.txtfogetid.Location = new System.Drawing.Point(196, 23);
            this.txtfogetid.Name = "txtfogetid";
            this.txtfogetid.Size = new System.Drawing.Size(212, 26);
            this.txtfogetid.TabIndex = 6;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(32, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 20);
            this.label23.TabIndex = 2;
            this.label23.Text = " User ID ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(32, 210);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(159, 20);
            this.label26.TabIndex = 5;
            this.label26.Text = "Conform Password";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(32, 75);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(87, 20);
            this.label24.TabIndex = 3;
            this.label24.Text = "Pet Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(32, 145);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(125, 20);
            this.label25.TabIndex = 4;
            this.label25.Text = "New Password";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.ChangePassword;
            this.pictureBox3.Location = new System.Drawing.Point(120, 61);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(293, 319);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Teal;
            this.label22.Location = new System.Drawing.Point(520, -4);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(271, 30);
            this.label22.TabIndex = 0;
            this.label22.Text = "Password recovery Panel";
            // 
            // panelchangepasswoed
            // 
            this.panelchangepasswoed.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelchangepasswoed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelchangepasswoed.Controls.Add(this.panel1);
            this.panelchangepasswoed.Controls.Add(this.pictureBox2);
            this.panelchangepasswoed.Controls.Add(this.label14);
            this.panelchangepasswoed.Location = new System.Drawing.Point(40, 65);
            this.panelchangepasswoed.MaximumSize = new System.Drawing.Size(1235, 460);
            this.panelchangepasswoed.Name = "panelchangepasswoed";
            this.panelchangepasswoed.Size = new System.Drawing.Size(1235, 460);
            this.panelchangepasswoed.TabIndex = 59;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnchange);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.txtchangeconpassword);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.txtchangenewpass);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.txtchangeoldpass);
            this.panel1.Location = new System.Drawing.Point(523, 84);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(516, 315);
            this.panel1.TabIndex = 8;
            // 
            // btnchange
            // 
            this.btnchange.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.btnchange.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnchange.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnchange.Location = new System.Drawing.Point(369, 240);
            this.btnchange.Name = "btnchange";
            this.btnchange.Size = new System.Drawing.Size(111, 45);
            this.btnchange.TabIndex = 8;
            this.btnchange.Text = "Change";
            this.btnchange.UseVisualStyleBackColor = true;
            this.btnchange.Click += new System.EventHandler(this.change_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(18, 181);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(159, 20);
            this.label21.TabIndex = 7;
            this.label21.Text = "Conform Password";
            // 
            // txtchangeconpassword
            // 
            this.txtchangeconpassword.Location = new System.Drawing.Point(238, 178);
            this.txtchangeconpassword.Name = "txtchangeconpassword";
            this.txtchangeconpassword.PasswordChar = '*';
            this.txtchangeconpassword.Size = new System.Drawing.Size(218, 26);
            this.txtchangeconpassword.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 115);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(172, 20);
            this.label20.TabIndex = 6;
            this.label20.Text = "Enter new Password";
            // 
            // txtchangenewpass
            // 
            this.txtchangenewpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtchangenewpass.Location = new System.Drawing.Point(238, 107);
            this.txtchangenewpass.Name = "txtchangenewpass";
            this.txtchangenewpass.PasswordChar = '*';
            this.txtchangenewpass.Size = new System.Drawing.Size(218, 32);
            this.txtchangenewpass.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 47);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(164, 20);
            this.label15.TabIndex = 5;
            this.label15.Text = "Enter old Password";
            // 
            // txtchangeoldpass
            // 
            this.txtchangeoldpass.Location = new System.Drawing.Point(238, 50);
            this.txtchangeoldpass.Name = "txtchangeoldpass";
            this.txtchangeoldpass.Size = new System.Drawing.Size(218, 26);
            this.txtchangeoldpass.TabIndex = 2;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.ChangePassword;
            this.pictureBox2.Location = new System.Drawing.Point(127, 78);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(293, 319);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Malgun Gothic Semilight", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Green;
            this.label14.Location = new System.Drawing.Point(526, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(431, 41);
            this.label14.TabIndex = 1;
            this.label14.Text = "Change Password  panel";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(1017, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(307, 26);
            this.dateTimePicker1.TabIndex = 58;
            // 
            // Changeadmin
            // 
            this.Changeadmin.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Changeadmin.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Changeadmin.Controls.Add(this.label4);
            this.Changeadmin.Controls.Add(this.pnlnewadmin);
            this.Changeadmin.Controls.Add(this.oldadminpanel);
            this.Changeadmin.Location = new System.Drawing.Point(40, 65);
            this.Changeadmin.MaximumSize = new System.Drawing.Size(1235, 460);
            this.Changeadmin.MinimumSize = new System.Drawing.Size(1235, 460);
            this.Changeadmin.Name = "Changeadmin";
            this.Changeadmin.Size = new System.Drawing.Size(1235, 460);
            this.Changeadmin.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(897, 281);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(330, 142);
            this.label4.TabIndex = 23;
            this.label4.Text = resources.GetString("label4.Text");
            // 
            // pnlnewadmin
            // 
            this.pnlnewadmin.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pnlnewadmin.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlnewadmin.Controls.Add(this.txtadhar);
            this.pnlnewadmin.Controls.Add(this.label13);
            this.pnlnewadmin.Controls.Add(this.label17);
            this.pnlnewadmin.Controls.Add(this.txtdob);
            this.pnlnewadmin.Controls.Add(this.newadminpanel);
            this.pnlnewadmin.Controls.Add(this.txtpetname);
            this.pnlnewadmin.Controls.Add(this.btnreset);
            this.pnlnewadmin.Controls.Add(this.txtpassnew);
            this.pnlnewadmin.Controls.Add(this.btnsubmit);
            this.pnlnewadmin.Controls.Add(this.label7);
            this.pnlnewadmin.Controls.Add(this.label8);
            this.pnlnewadmin.Controls.Add(this.txtname);
            this.pnlnewadmin.Controls.Add(this.label12);
            this.pnlnewadmin.Controls.Add(this.label3);
            this.pnlnewadmin.Controls.Add(this.txtconpass);
            this.pnlnewadmin.Controls.Add(this.txtidnew);
            this.pnlnewadmin.Controls.Add(this.label6);
            this.pnlnewadmin.Controls.Add(this.label5);
            this.pnlnewadmin.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlnewadmin.Location = new System.Drawing.Point(443, -2);
            this.pnlnewadmin.Name = "pnlnewadmin";
            this.pnlnewadmin.Size = new System.Drawing.Size(762, 459);
            this.pnlnewadmin.TabIndex = 22;
            this.pnlnewadmin.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlnewadmin_Paint);
            // 
            // txtadhar
            // 
            this.txtadhar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadhar.Location = new System.Drawing.Point(207, 309);
            this.txtadhar.Multiline = true;
            this.txtadhar.Name = "txtadhar";
            this.txtadhar.Size = new System.Drawing.Size(186, 28);
            this.txtadhar.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label13.Location = new System.Drawing.Point(30, 309);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 20);
            this.label13.TabIndex = 20;
            this.label13.Text = "Adhar";
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.Location = new System.Drawing.Point(0, 398);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(469, 58);
            this.label17.TabIndex = 29;
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtdob
            // 
            this.txtdob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdob.Location = new System.Drawing.Point(207, 268);
            this.txtdob.Multiline = true;
            this.txtdob.Name = "txtdob";
            this.txtdob.Size = new System.Drawing.Size(182, 29);
            this.txtdob.TabIndex = 7;
            // 
            // newadminpanel
            // 
            this.newadminpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.newadminpanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newadminpanel.ForeColor = System.Drawing.SystemColors.Control;
            this.newadminpanel.Location = new System.Drawing.Point(-6, 0);
            this.newadminpanel.Name = "newadminpanel";
            this.newadminpanel.Size = new System.Drawing.Size(475, 46);
            this.newadminpanel.TabIndex = 20;
            this.newadminpanel.Text = "Enter New admin Record";
            this.newadminpanel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtpetname
            // 
            this.txtpetname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpetname.Location = new System.Drawing.Point(207, 219);
            this.txtpetname.Multiline = true;
            this.txtpetname.Name = "txtpetname";
            this.txtpetname.Size = new System.Drawing.Size(234, 28);
            this.txtpetname.TabIndex = 6;
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnreset.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnreset.Location = new System.Drawing.Point(263, 355);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(75, 33);
            this.btnreset.TabIndex = 9;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // txtpassnew
            // 
            this.txtpassnew.Location = new System.Drawing.Point(207, 96);
            this.txtpassnew.Multiline = true;
            this.txtpassnew.Name = "txtpassnew";
            this.txtpassnew.PasswordChar = '*';
            this.txtpassnew.Size = new System.Drawing.Size(186, 26);
            this.txtpassnew.TabIndex = 3;
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnsubmit.Location = new System.Drawing.Point(368, 355);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 33);
            this.btnsubmit.TabIndex = 10;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label7.Location = new System.Drawing.Point(36, 270);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "DOB";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label8.Location = new System.Drawing.Point(36, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "User ID";
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(207, 177);
            this.txtname.Multiline = true;
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(234, 28);
            this.txtname.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label12.Location = new System.Drawing.Point(36, 102);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 20);
            this.label12.TabIndex = 1;
            this.label12.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label3.Location = new System.Drawing.Point(30, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Pet Name";
            // 
            // txtconpass
            // 
            this.txtconpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtconpass.Location = new System.Drawing.Point(206, 139);
            this.txtconpass.Multiline = true;
            this.txtconpass.Name = "txtconpass";
            this.txtconpass.PasswordChar = '*';
            this.txtconpass.Size = new System.Drawing.Size(194, 25);
            this.txtconpass.TabIndex = 4;
            // 
            // txtidnew
            // 
            this.txtidnew.Location = new System.Drawing.Point(206, 63);
            this.txtidnew.Multiline = true;
            this.txtidnew.Name = "txtidnew";
            this.txtidnew.Size = new System.Drawing.Size(186, 26);
            this.txtidnew.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label6.Location = new System.Drawing.Point(30, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Conf. Passowed";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label5.Location = new System.Drawing.Point(30, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Admin Name";
            // 
            // oldadminpanel
            // 
            this.oldadminpanel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.oldadminpanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.oldadminpanel.Controls.Add(this.label16);
            this.oldadminpanel.Controls.Add(this.label9);
            this.oldadminpanel.Controls.Add(this.btnsearch);
            this.oldadminpanel.Controls.Add(this.txtoldpass);
            this.oldadminpanel.Controls.Add(this.txtoldid);
            this.oldadminpanel.Controls.Add(this.label11);
            this.oldadminpanel.Controls.Add(this.label10);
            this.oldadminpanel.Location = new System.Drawing.Point(-1, -3);
            this.oldadminpanel.Name = "oldadminpanel";
            this.oldadminpanel.Size = new System.Drawing.Size(421, 462);
            this.oldadminpanel.TabIndex = 21;
            this.oldadminpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.oldadminpanel_Paint);
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label16.Location = new System.Drawing.Point(-2, 399);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(421, 61);
            this.label16.TabIndex = 28;
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(0, -2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(418, 51);
            this.label9.TabIndex = 27;
            this.label9.Text = "Enter Old admin Record";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnsearch.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.btnsearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnsearch.Location = new System.Drawing.Point(159, 266);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(119, 53);
            this.btnsearch.TabIndex = 26;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txtoldpass
            // 
            this.txtoldpass.Location = new System.Drawing.Point(132, 207);
            this.txtoldpass.Multiline = true;
            this.txtoldpass.Name = "txtoldpass";
            this.txtoldpass.PasswordChar = '*';
            this.txtoldpass.Size = new System.Drawing.Size(217, 34);
            this.txtoldpass.TabIndex = 25;
            // 
            // txtoldid
            // 
            this.txtoldid.Location = new System.Drawing.Point(132, 152);
            this.txtoldid.Multiline = true;
            this.txtoldid.Name = "txtoldid";
            this.txtoldid.Size = new System.Drawing.Size(219, 37);
            this.txtoldid.TabIndex = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(17, 216);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 20);
            this.label11.TabIndex = 23;
            this.label11.Text = "Password";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label10.Location = new System.Drawing.Point(24, 158);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 20);
            this.label10.TabIndex = 22;
            this.label10.Text = "User ID";
            // 
            // loginpanal
            // 
            this.loginpanal.BackColor = System.Drawing.Color.Silver;
            this.loginpanal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.loginpanal.Controls.Add(this.panel3);
            this.loginpanal.Controls.Add(this.pictureBox1);
            this.loginpanal.Location = new System.Drawing.Point(40, 65);
            this.loginpanal.Name = "loginpanal";
            this.loginpanal.Size = new System.Drawing.Size(1235, 460);
            this.loginpanal.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightGray;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.txtpassword);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.btnlogin);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.txtid);
            this.panel3.Location = new System.Drawing.Point(663, 92);
            this.panel3.MaximumSize = new System.Drawing.Size(506, 260);
            this.panel3.MinimumSize = new System.Drawing.Size(506, 260);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(506, 260);
            this.panel3.TabIndex = 7;
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(210, 121);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.PasswordChar = '*';
            this.txtpassword.Size = new System.Drawing.Size(186, 26);
            this.txtpassword.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(111, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "User ID";
            // 
            // btnlogin
            // 
            this.btnlogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnlogin.ForeColor = System.Drawing.Color.White;
            this.btnlogin.Location = new System.Drawing.Point(254, 173);
            this.btnlogin.Name = "btnlogin";
            this.btnlogin.Size = new System.Drawing.Size(78, 32);
            this.btnlogin.TabIndex = 4;
            this.btnlogin.Text = "Login";
            this.btnlogin.UseVisualStyleBackColor = false;
            this.btnlogin.Click += new System.EventHandler(this.btnlogin_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(96, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password";
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(206, 58);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(186, 26);
            this.txtid.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.IMG_20171004_WA0012_1_;
            this.pictureBox1.Location = new System.Drawing.Point(1, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(606, 459);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnmenulogin
            // 
            this.btnmenulogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnmenulogin.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.btnmenulogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnmenulogin.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnmenulogin.Location = new System.Drawing.Point(0, 0);
            this.btnmenulogin.Name = "btnmenulogin";
            this.btnmenulogin.Size = new System.Drawing.Size(125, 50);
            this.btnmenulogin.TabIndex = 3;
            this.btnmenulogin.Text = "Login";
            this.btnmenulogin.UseVisualStyleBackColor = false;
            this.btnmenulogin.Click += new System.EventHandler(this.btnmenulogin_Click);
            // 
            // btnnewAdmin
            // 
            this.btnnewAdmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnnewAdmin.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.btnnewAdmin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnnewAdmin.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnnewAdmin.Location = new System.Drawing.Point(119, 0);
            this.btnnewAdmin.Name = "btnnewAdmin";
            this.btnnewAdmin.Size = new System.Drawing.Size(175, 49);
            this.btnnewAdmin.TabIndex = 7;
            this.btnnewAdmin.Text = "Change Admin ";
            this.btnnewAdmin.UseVisualStyleBackColor = false;
            this.btnnewAdmin.Click += new System.EventHandler(this.btnnewAdmin_Click);
            // 
            // btnchangpass
            // 
            this.btnchangpass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnchangpass.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.btnchangpass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnchangpass.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnchangpass.Location = new System.Drawing.Point(289, 0);
            this.btnchangpass.Name = "btnchangpass";
            this.btnchangpass.Size = new System.Drawing.Size(161, 48);
            this.btnchangpass.TabIndex = 1;
            this.btnchangpass.Text = "Change Password";
            this.btnchangpass.UseVisualStyleBackColor = false;
            this.btnchangpass.Click += new System.EventHandler(this.btnchangpass_Click);
            // 
            // btnforget
            // 
            this.btnforget.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnforget.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.all_schoolbg2;
            this.btnforget.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnforget.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnforget.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnforget.Location = new System.Drawing.Point(447, 0);
            this.btnforget.Name = "btnforget";
            this.btnforget.Size = new System.Drawing.Size(152, 48);
            this.btnforget.TabIndex = 0;
            this.btnforget.Text = "Forget Password";
            this.btnforget.UseVisualStyleBackColor = false;
            this.btnforget.Click += new System.EventHandler(this.btnforget_Click);
            // 
            // pnlHedding
            // 
            this.pnlHedding.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlHedding.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlHedding.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlHedding.Controls.Add(this.btnExit);
            this.pnlHedding.Controls.Add(this.label18);
            this.pnlHedding.Controls.Add(this.label19);
            this.pnlHedding.Location = new System.Drawing.Point(1, 0);
            this.pnlHedding.Name = "pnlHedding";
            this.pnlHedding.Size = new System.Drawing.Size(1347, 110);
            this.pnlHedding.TabIndex = 57;
            this.pnlHedding.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlHedding_Paint);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Font = new System.Drawing.Font("Javanese Text", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(268, 18);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(628, 64);
            this.label19.TabIndex = 4;
            this.label19.Text = "GOVERNMENT POLYTECHNIC GHAZIABAD";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Font = new System.Drawing.Font("Maiandra GD", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Green;
            this.button7.Location = new System.Drawing.Point(1215, 0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(84, 35);
            this.button7.TabIndex = 9;
            this.button7.Text = "Logout";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // txtadmin
            // 
            this.txtadmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtadmin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtadmin.Font = new System.Drawing.Font("Prestige Elite Std", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadmin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtadmin.Location = new System.Drawing.Point(-2, -1);
            this.txtadmin.Multiline = true;
            this.txtadmin.Name = "txtadmin";
            this.txtadmin.Size = new System.Drawing.Size(422, 32);
            this.txtadmin.TabIndex = 15;
            this.txtadmin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtadmin.TextChanged += new System.EventHandler(this.txtadmin_TextChanged);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnExit.BackgroundImage = global::GPG_LIBRARY_MANAGEMENT.Properties.Resources.logout1;
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnExit.Font = new System.Drawing.Font("Maiandra GD", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.Green;
            this.btnExit.Location = new System.Drawing.Point(1259, -1);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(62, 61);
            this.btnExit.TabIndex = 18;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // Form1
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1348, 687);
            this.ControlBox = false;
            this.Controls.Add(this.pnlHedding);
            this.Controls.Add(this.panel4);
            this.MaximumSize = new System.Drawing.Size(1364, 726);
            this.MinimumSize = new System.Drawing.Size(1364, 726);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel4.ResumeLayout(false);
            this.homepanel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.forgetpanel.ResumeLayout(false);
            this.forgetpanel.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelchangepasswoed.ResumeLayout(false);
            this.panelchangepasswoed.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.Changeadmin.ResumeLayout(false);
            this.Changeadmin.PerformLayout();
            this.pnlnewadmin.ResumeLayout(false);
            this.pnlnewadmin.PerformLayout();
            this.oldadminpanel.ResumeLayout(false);
            this.oldadminpanel.PerformLayout();
            this.loginpanal.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlHedding.ResumeLayout(false);
            this.pnlHedding.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnmenulogin;
        private System.Windows.Forms.Button btnnewAdmin;
        private System.Windows.Forms.Button btnchangpass;
        private System.Windows.Forms.Button btnforget;
        internal System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel Changeadmin;
        private System.Windows.Forms.Panel pnlnewadmin;
        private System.Windows.Forms.Label newadminpanel;
        private System.Windows.Forms.TextBox txtpassnew;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.TextBox txtpetname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtconpass;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtidnew;
        private System.Windows.Forms.Panel oldadminpanel;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox txtoldpass;
        private System.Windows.Forms.TextBox txtoldid;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtadhar;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel pnlHedding;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel loginpanal;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnlogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtdob;
        private System.Windows.Forms.Panel panelchangepasswoed;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnchange;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtchangeconpassword;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtchangenewpass;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtchangeoldpass;
        private System.Windows.Forms.Panel forgetpanel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnforgetgo;
        private System.Windows.Forms.TextBox txtforgetconpass;
        private System.Windows.Forms.TextBox txtforgetpass;
        private System.Windows.Forms.TextBox txtforgetpetname;
        private System.Windows.Forms.TextBox txtfogetid;
        private System.Windows.Forms.Panel homepanel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtadmin;
        private System.Windows.Forms.Button btnExit;
    }
}

