﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.IO;
namespace GPG_LIBRARY_MANAGEMENT
{
    public partial class student_Reg : Form
    {


        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\HTML Web Projec\\GPG LIBRARY MANAGEMENT\\GPG LIBRARY MANAGEMENT\\Database1.mdf;Integrated Security=True;User Instance=True");
       
        public student_Reg()
        {
            InitializeComponent();
        }

           

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
         
        }

        private void student_Reg_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            btnsubmit.Visible =false;
            btnsearch.Visible = false;
            btndel.Visible = false;
            btnupdate.Visible =true;
            btnreset.Visible = true;




        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "select * from StudentDB where StudentID=@StudentID";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);
           SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                txtStudentID.Text  = dr["StudentID"].ToString();
                txtStudentname.Text = dr["StudentName"].ToString();
                cobBranch.Text = dr["Branch"].ToString();
                txtadhar.Text = dr["Adhar"].ToString();
                txtfather.Text = dr["FatherNmae"].ToString();
                txtmobile.Text = dr["MN"].ToString();
                txtlocaladd.Text = dr["LocalAddress"].ToString();
                txtpAdd.Text = dr["PermanentAddress"].ToString();
                
                byte[] data = (byte[])dr["Image"];   
                MemoryStream m = new MemoryStream(data);
                 pic.Image = Image.FromStream(m);
                
                
            }
            else
                MessageBox.Show("Record not found");

            con.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
           

            if (txtadhar.Text != "" && txtfather.Text != "" && txtStudentID.Text != "" && txtStudentname.Text != "" && cobBranch.Text != "" && txtmobile.Text != "" && txtlocaladd.Text != "" && txtpAdd.Text != ""&& pic.Image != null)
            {
                con.Open();
                string sql = "INSERT INTO StudentDB values(@StudentID,@StudentName,@Branch,@Adhar,@FatherName,@MN,@LocalAddress,@PermanentAddress,@Image)";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text);
                cmd.Parameters.AddWithValue("@StudentName", txtStudentname.Text);
                cmd.Parameters.AddWithValue("@Branch", cobBranch.Text);
                cmd.Parameters.AddWithValue("@Adhar", txtadhar.Text);
                cmd.Parameters.AddWithValue("@FatherName", txtfather.Text);
                cmd.Parameters.AddWithValue("@MN", txtmobile.Text);
                cmd.Parameters.AddWithValue("@LocalAddress", txtlocaladd.Text);
                cmd.Parameters.AddWithValue("@PermanentAddress", txtpAdd.Text);
                // cmd.Parameters.AddWithValue("@Image",pic.Image);

                SqlParameter p = new SqlParameter("@Image", SqlDbType.Image);
                MemoryStream ms = new MemoryStream();
                pic.Image.Save(ms, pic.Image.RawFormat);
                byte[] data = ms.GetBuffer();
                p.Value = data;

                cmd.Parameters.Add(p);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record successfully Saved");

                txtadhar.Text = "";
                txtfather.Text = "";
                txtlocaladd.Text = "";
                txtmobile.Text = "";
                txtpAdd.Text = "";
                txtStudentID.Text = "";
                txtStudentname.Text = "";
                cobBranch.Text = "";
                pic.Image = null;
                }
            else 
            {
                MessageBox.Show("Please Fill all Box ");
            }
            
           
        }

        private void button3_Click(object sender, EventArgs e)
        {

            openFileDialog1.ShowDialog();
            pic.Image = Image.FromFile(openFileDialog1.FileName);
            openFileDialog1.Filter = "jpeg|*.jpg|bmp|*.bmp|all files|*.*";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            btnsubmit.Visible = true;
            btnsearch.Visible = false;
            btndel.Visible = false;
            btnupdate.Visible = false;
            btnreset.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {

            btnsubmit.Visible = false;
            btnsearch.Visible = true;
            btndel.Visible = false;
            btnupdate.Visible = false;
            btnreset.Visible = true;
        }

       

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtadhar.Text = "";
            txtfather.Text = "";
            txtlocaladd.Text = "";
            txtmobile.Text = "";
            txtpAdd.Text = "";
            txtStudentID.Text = "";
            txtStudentname.Text = "";
            cobBranch.Text = "";
            pic.Image = null;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            con.Open();
             string d = ("delete from StudentDB where StudentID='" + txtStudentID.Text + "'");
             SqlCommand cmdd = new SqlCommand(d, con); 
              String message = " Are you sure that this Record are deleted ";
              string a=" if  "
              string title = "Conformation ";
              MessageBoxButtons button = MessageBoxButtons.YesNo;
              DialogResult result = MessageBox.Show(message, title, button);
              if (result == DialogResult.Yes)
              {
                  cmdd.ExecuteNonQuery();
                  con.Close();
                  MessageBox.Show("Record deleted ");
                  txtadhar.Text = "";
                  txtfather.Text = "";
                  txtlocaladd.Text = "";
                  txtmobile.Text = "";
                  txtpAdd.Text = "";
                  txtStudentID.Text = "";
                  txtStudentname.Text = "";
                  cobBranch.Text = "";
                  pic.Image = null;

              }

              else
              {
                  con.Close();
              
              }
 

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

        }

       
    }
}
