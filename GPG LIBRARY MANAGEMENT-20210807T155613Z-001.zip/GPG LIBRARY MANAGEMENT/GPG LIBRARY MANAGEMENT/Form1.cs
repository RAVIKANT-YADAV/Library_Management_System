﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace GPG_LIBRARY_MANAGEMENT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
      
        SqlDataReader sdr;



        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=D:\\HTML Web Projec\\GPG LIBRARY MANAGEMENT\\GPG LIBRARY MANAGEMENT\\Database1.mdf;Integrated Security=True;User Instance=True");
       

        private void Form1_Load(object sender, EventArgs e)
        {



           
            pnlnewadmin.Enabled = false;
            Changeadmin.Visible = false;
            panelchangepasswoed.Visible = false;
            forgetpanel.Visible = false;
            homepanel.Visible=false;
            
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnmenulogin_Click(object sender, EventArgs e)
        {
            loginpanal.Visible = true;
            Changeadmin.Visible = false;
            panelchangepasswoed.Visible = false;
            forgetpanel.Visible = false;
            homepanel.Visible = false;

        }

        private void oldadminpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnnewAdmin_Click(object sender, EventArgs e)
        {
            Changeadmin.Visible = true;
            loginpanal.Visible = false;
            panelchangepasswoed.Visible = false;
            forgetpanel.Visible = false;
            homepanel.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
            {
                con.Open();
                string search = "select * from adminDatabase where ID='" + txtoldid.Text + "'";
                SqlCommand cmd = new SqlCommand(search, con);
                sdr = cmd.ExecuteReader();
                 if (sdr.HasRows)
                 {
                     sdr.Read();
                     if (txtoldpass.Text == sdr.GetString(1).ToString())
                         {

                             sdr.Close();

                             string d = ("delete from adminDatabase where ID='" + txtoldid.Text + "'");
                             SqlCommand cmdd = new SqlCommand(d, con);
                             cmdd.ExecuteNonQuery();
                             MessageBox.Show("Old Admin Record  Is Currect Pleace Enter New Admine  And Remember Your ID and Password  ");
                             pnlnewadmin.Enabled = true;
                             oldadminpanel.Visible = false;
                             con.Close();
                             btnchangpass.Enabled = false;
                             btnforget.Enabled = false;
                             btnlogin.Enabled = false;
                             btnmenulogin.Enabled = false;           
                         }

                         else
                         {
                             MessageBox.Show(" Error ! User Id or Password  Invalide ");
                             con.Close();
                         }
                     
                 }
                 else
                 {
                     con.Close();
                     txtoldid.Text = "";
                     txtoldpass.Text = "";

                     MessageBox.Show("You are not Authorities for this Panel ");
                 }
                
               

            }

        

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtidnew.Text = "";
            txtpassnew.Text = "";
            txtconpass.Text = "";
            txtname.Text = "";
            txtpetname.Text = "";
            txtadhar.Text = "";
             txtdob.Text="";

        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtidnew.Text != "" && txtpassnew.Text != "" && txtname.Text != "" && txtpetname.Text != "" && txtdob.Text != "" && txtadhar.Text != "")
                {
                    con.Open();
                    String User = "insert into adminDatabase values('" + txtidnew.Text + "','" + txtpassnew.Text + "','" + txtname.Text + "','" + txtpetname.Text + "','" + txtdob.Text + "','" + txtadhar.Text + "')";
                    SqlCommand cmd = new SqlCommand(User, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Registration  Successfully   ! Wellcome !");
                    oldadminpanel.Visible = true;
                    btnchangpass.Enabled = true;
                    btnforget.Enabled = true;
                    btnlogin.Enabled = true;
                    btnmenulogin.Enabled = true;
                    loginpanal.Visible = true;
                    Changeadmin.Visible = false;
                    con.Close();

                    txtpassnew.Text = "";
                    txtconpass.Text = "";
                    txtadhar.Text = "";
                    txtpetname.Text = "";
                    txtdob.Text = "";
                    txtidnew.Text = "";
                    txtname.Text = "";


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void pnlnewadmin_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtid.Text != "")
                {
                    con.Open();
                    string search = "select * from adminDatabase where ID='" + txtid.Text + "'";
                    SqlCommand cmd = new SqlCommand(search, con);
                    sdr = cmd.ExecuteReader();
                    if (sdr.HasRows)
                    {
                        sdr.Read();
                     
                        string name = sdr["name"].ToString();
                        if (txtpassword.Text == sdr.GetString(1).ToString())
                        {

                           
                            homepanel.Visible = true;
                            con.Close();
                            txtid.Text = "";
                            txtpassword.Text = "";
                            
                            MessageBox.Show("Welcome  " + name + "\n to GPG Library Management System");
                            btnExit.Visible = false;
                            txtadmin.Text = name;



                        }
                        else
                        {
                            MessageBox.Show("  Password  Invalide ");
                            txtpassword.Text = "";
                            con.Close();
                        }
                    }
                    else
                    {
                        con.Close();
                        MessageBox.Show("You are not Authorities for this Panel ");
                        txtid.Text = "";
                        txtpassword.Text = "";
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
           // panelhome.Visible = false;
        }

        private void btnchangpass_Click(object sender, EventArgs e)
        {
            panelchangepasswoed.Visible = true;
            loginpanal.Visible = false;
            Changeadmin.Visible = false;
            forgetpanel.Visible =false;
            
        }

        private void pnlHedding_Paint(object sender, PaintEventArgs e)
        {

        }

        private void change_Click(object sender, EventArgs e)
        {
            if (txtchangeconpassword.Text == txtchangenewpass.Text)
            {
                con.Open();
                string update = "Update adminDatabase set password ='" + txtchangenewpass.Text + "' Where password='" + txtchangeoldpass.Text + "'";
                SqlCommand cmd = new SqlCommand(update, con);
                if (cmd.ExecuteNonQuery() !=0)
                {
                    con.Close();
                    MessageBox.Show("Your Password is Change ");
                    panelchangepasswoed.Visible = false;
                    loginpanal.Visible = true;
                }
                else
                {
                    MessageBox.Show("Your Password is Incorrect ! Re-enter ");
                    con.Close();
                }
            }
            else
            {
                txtchangeconpassword.Text = "";
               
            }

        
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)


        {  con.Open();
            string update = "Update adminDatabase set password ='" +txtforgetpass.Text + "' Where Petname='" +txtforgetpetname.Text+ "'";
            SqlCommand cmd = new SqlCommand(update, con);
            if (cmd.ExecuteNonQuery() != 0)
            {
                con.Close();
                MessageBox.Show("New password is  suscessfully created \n Remember this password  ");
                forgetpanel.Visible = false;
                loginpanal.Visible = true;
                

            }
            else
            {
                MessageBox.Show(" your pet Name is not currect ");
                txtforgetpetname.Text = "";
                con.Close();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnforget_Click(object sender, EventArgs e)
        {
            forgetpanel.Visible = true;
            loginpanal.Visible = false;
            Changeadmin.Visible = false;
            panelchangepasswoed.Visible = false;
           
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Book_Entry ob = new Book_Entry();
            ob.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Issu_Book ob = new Issu_Book();
            ob.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            student_Reg ob = new student_Reg();
            ob.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Return_Book ob = new Return_Book();
            ob.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

            homepanel.Visible = false;
            btnExit.Visible = true;
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void admin_Click(object sender, EventArgs e)
        {
            
        }

        private void txtadmin_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

    }
}
