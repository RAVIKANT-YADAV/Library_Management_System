﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GPG_LIBRARY_MANAGEMENT
{
    public partial class Book_Entry : Form
    {
        public Book_Entry()
        {
            InitializeComponent();
        }

        private void Book_Entry_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
